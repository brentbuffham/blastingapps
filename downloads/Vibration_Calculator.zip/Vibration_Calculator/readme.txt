*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*^*

To launch the program double click on the file named "Vibration_Calculator.jar"

***************************************************************************
***************************************************************************
**   NO Guarantees or warranties are supplied with this program.         **
**   Information used from this program is utilized at the users risk.   **
***************************************************************************
***************************************************************************

Vibration Calculator

Authored by Brent Buffham

Date : 8/7/2008

***************************************************************************
                            Free to distribute.
   However it must have the accompanied source code and readme.txt file.

                  Please give credit where credit is due!

                         brent.buffham@gmail.com


 Please feel free to distribute.  Please give credit where credit is due.

***************************************************************************
**   NO Guarantees or warranties are supplied with this program.         **
**   Information used from this program is utilized at the users risk.   **
***************************************************************************

If you have any comments or suggestions please feel free to email me

			brent.buffham@gmail.com

To launch the program double click on the file named "Vibration_Calculator.jar"